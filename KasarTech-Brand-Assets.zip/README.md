# KasarTech.ai Production Brand Asset Pack

Includes:
- Primary light/dark/white SVG logo
- Wordmark-only SVG
- Standalone symbol SVG
- Black/white symbol variants
- Favicon 16/32/48px
- Apple Touch Icon 180px
- PWA icons 192/512px
- Dark and white app icons
- favicon.ico
- Brand color reference

Use SVG masters wherever possible. PNG/ICO files are for browser/app compatibility.

Note: this is a technical production asset pack based on the selected concept. It is not a trademark-clearance certificate.
